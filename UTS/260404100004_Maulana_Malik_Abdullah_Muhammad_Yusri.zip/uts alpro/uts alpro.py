#pemesanan tiket
reguler = 40000
VIP = 75000
VVIP = 100000
while True:
   tiket = input("masukkan jumlah tiket: ")
        if tiket = reguler:
        print("apakah anda ingin membeli minuman? "){y/n}
            if y:
            reguler += 10000
            else:
            print("silahkan masuk")
        elif tiket == VIP or VVIP:
        print("otomatis mendapat minuman")

        